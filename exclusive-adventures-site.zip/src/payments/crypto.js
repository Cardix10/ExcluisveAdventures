// Lightweight ethers.js helper (client-side) for testnet demo
import { ethers } from 'ethers'

// Connects to MetaMask (or injected provider)
export async function connectWallet(){
  if(!window.ethereum) throw new Error('MetaMask not detected')
  await window.ethereum.request({ method: 'eth_requestAccounts' })
  const provider = new ethers.BrowserProvider(window.ethereum)
  const signer = await provider.getSigner()
  const address = await signer.getAddress()
  return { provider, signer, address }
}

// Send a tiny testnet payment to a test address (do NOT use on mainnet)
export async function sendTestnetPayment(amountEth = '0.001'){
  const { signer } = await connectWallet()
  // Example testnet recipient (replace with your test address)
  const to = '0x0000000000000000000000000000000000000001'
  const tx = await signer.sendTransaction({ to, value: ethers.parseEther(amountEth) })
  return tx
}

// Notes:
// - For a production flow, use a server to create payment intents and verify payments.
// - Use Coinbase Commerce or a payment gateway for custodial crypto flows.
// - Keep private keys off the client.
