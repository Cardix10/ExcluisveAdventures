import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useForm } from 'react-hook-form'
import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup'
import { connectWallet, sendTestnetPayment } from './payments/crypto'

const schema = yup.object({
  fullName: yup.string().required('Full name is required'),
  email: yup.string().email('Enter a valid email').required('Email is required'),
  message: yup.string().optional()
})

export default function App(){
  const [inviteModal, setInviteModal] = useState(false)
  const [thankYou, setThankYou] = useState(false)
  const [loading, setLoading] = useState(false)
  const { register, handleSubmit, formState: { errors }, reset } = useForm({ resolver: yupResolver(schema) })

  async function onSubmit(data){
    setLoading(true)
    try{
      // Placeholder POSTs — replace URLs with real endpoints or server functions.
      await fetch('/api/mailchimp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ list: 'MAILCHIMP_LIST_ID', ...data })
      })

      await fetch('https://hooks.example.com/google-sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })

      if(window.gtag) window.gtag('event', 'invitation_signup', { method: 'landing_form' })

      reset()
      setInviteModal(false)
      setThankYou(true)
    }catch(e){
      console.error(e)
      alert('Submission failed — please try again later.')
    }finally{
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen font-inter bg-black text-white">
      <header className="fixed top-0 left-0 right-0 z-40 bg-transparent p-6">
        <nav className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="text-xl font-bold tracking-wide">Exclusive Adventures</div>
          <div className="space-x-6">
            <a href="#destinations" className="nav-link">Destinations</a>
            <a href="#about" className="nav-link">About</a>
            <button onClick={()=>setInviteModal(true)} className="btn-ghost">Request an Invitation</button>
          </div>
        </nav>
      </header>

      <main>
        <section className="relative h-screen flex items-center" aria-label="Hero">
          <video
            className="absolute inset-0 w-full h-full object-cover"
            autoPlay muted loop playsInline
            poster="/assets/hero-poster.jpg"
            preload="metadata"
          >
            <source src="/assets/hero-cartagena.mp4" type="video/mp4" />
          </video>

          <div className="absolute inset-0 bg-gradient-to-b from-[rgba(0,0,0,0.35)] via-[rgba(0,0,0,0.5)] to-[rgba(15,7,0,0.85)]" aria-hidden></div>

          <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
            <h1 className="playfair text-5xl md:text-7xl font-extrabold leading-tight">Experience Colombia’s Most Exclusive Adventures</h1>
            <p className="mt-6 max-w-2xl mx-auto text-lg md:text-xl">From Cartagena’s coastlines to Medellín’s mountains and Cali’s rhythm — discover bespoke journeys curated just for you.</p>

            <div className="mt-10 flex justify-center gap-4">
              <button
                className="cta-primary"
                onClick={()=>{ if(window.gtag) window.gtag('event','cta_click',{label:'Join the Journey'}); window.location.href='#featured' }}
              >Join the Journey</button>
              <button className="cta-outline" onClick={()=>setInviteModal(true)}>Request an Invitation</button>
            </div>
          </div>
        </section>

        <section id="featured" className="py-24">
          <div className="max-w-6xl mx-auto px-6">
            <h2 className="playfair text-4xl mb-8">Featured Experiences</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {title: 'Private Yacht Charter in Cartagena\'s Rosario Islands', img: '/assets/rosario.jpg'},
                {title: 'Helicopter Tour over Medellín\'s Aburrá Valley', img: '/assets/medellin.jpg'},
                {title: 'Luxury Salsa Weekend & Fine Dining in Cali', img: '/assets/cali.jpg'}
              ].map((d,i)=> (
                <motion.article key={i} whileHover={{ scale: 1.03 }} className="relative overflow-hidden rounded-2xl bg-gray-900 shadow-xl">
                  <img src={d.img} alt={d.title} className="w-full h-64 object-cover" loading="lazy" />
                  <div className="p-6">
                    <h3 className="font-semibold text-xl">{d.title}</h3>
                    <p className="mt-2 text-sm opacity-80">Bespoke itinerary, private guides, and exclusive access.</p>
                    <div className="mt-4">
                      <button className="card-cta">View Experience</button>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section id="about" className="py-24 bg-black/60">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <h2 className="playfair text-3xl">About Exclusive Adventures</h2>
            <p className="mt-6">Exclusive Adventures curates elite travel experiences across Colombia’s most captivating cities — blending adventure, comfort, and culture in perfect harmony.</p>
          </div>
        </section>

        <section className="py-24">
          <div className="max-w-4xl mx-auto px-6">
            <h2 className="playfair text-3xl">Membership</h2>
            <div className="mt-8 grid md:grid-cols-2 gap-8">
              <div className="p-8 rounded-2xl bg-gray-900/40">
                <h3 className="text-xl font-semibold">Explorer</h3>
                <p className="mt-2">Free — email access only</p>
                <div className="mt-4"><button className="card-cta">Join Explorer</button></div>
              </div>
              <div className="p-8 rounded-2xl bg-gradient-to-br from-[#0b0b0b] to-[#0b0500]/20">
                <h3 className="text-xl font-semibold">Elite</h3>
                <p className="mt-2">Premium — concierge, early access</p>
                <div className="mt-4">
                  <button className="card-cta" onClick={()=>setInviteModal(true)}>Request an Invitation</button>
                </div>
              </div>
            </div>
          </div>
        </section>

      </main>

      <footer className="py-12">
        <div className="max-w-6xl mx-auto px-6 text-center opacity-70">© {new Date().getFullYear()} Exclusive Adventures</div>
      </footer>

      <AnimatePresence>
        {inviteModal && (
          <motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}>
            <motion.div className="modal" initial={{scale:0.95, opacity:0}} animate={{scale:1, opacity:1}} exit={{scale:0.95, opacity:0}}>
              <h3 className="playfair text-2xl">Request an Invitation</h3>

              <form onSubmit={handleSubmit(onSubmit)} className="mt-4 space-y-4">
                <div>
                  <label className="sr-only">Full Name</label>
                  <input {...register('fullName')} placeholder="Full Name" className="form-input" aria-invalid={errors.fullName ? 'true' : 'false'} />
                  {errors.fullName && <span className="text-sm text-red-400">{errors.fullName.message}</span>}
                </div>
                <div>
                  <label className="sr-only">Email</label>
                  <input {...register('email')} placeholder="Email Address" className="form-input" aria-invalid={errors.email ? 'true' : 'false'} />
                  {errors.email && <span className="text-sm text-red-400">{errors.email.message}</span>}
                </div>
                <div>
                  <label className="sr-only">Message</label>
                  <textarea {...register('message')} placeholder="Tell us about your ideal adventure (optional)" className="form-textarea"></textarea>
                </div>

                <div className="flex items-center gap-4">
                  <button type="submit" className="btn-submit" disabled={loading}>{loading ? 'Sending…' : 'Submit Request'}</button>
                  <button type="button" className="btn-ghost" onClick={()=>setInviteModal(false)}>Cancel</button>
                </div>

                <div className="text-xs opacity-80 mt-2">We value your privacy — your information will be used only to process your invitation request.</div>
              </form>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {thankYou && (
          <motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}>
            <motion.div className="modal" initial={{scale:0.95, opacity:0}} animate={{scale:1, opacity:1}} exit={{scale:0.95, opacity:0}}>
              <h3 className="playfair text-2xl">Your request has been received</h3>
              <p className="mt-4">Our concierge team will contact you soon.</p>
              <div className="mt-6 flex gap-4 justify-center">
                <a href="https://instagram.com/exclusiveadventures" target="_blank" rel="noreferrer" className="card-cta">Instagram</a>
                <button className="btn-ghost" onClick={()=>setThankYou(false)}>Close</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  )
}
