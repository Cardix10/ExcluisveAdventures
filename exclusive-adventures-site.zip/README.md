# Exclusive Adventures — Quickstart

## Setup (local)
1. Install dependencies
```
npm install
```

2. Development
```
npm run start
```

3. Build
```
npm run build
```

4. Firebase deploy (local)
```
npm install -g firebase-tools
firebase login
firebase init hosting
firebase deploy
```

## Google Cloud Storage alternative
```
gsutil mb gs://exclusive-adventures
gsutil rsync -R ./dist gs://exclusive-adventures
gsutil iam ch allUsers:objectViewer gs://exclusive-adventures
```

## GitHub Actions
- Push to `main` to auto-deploy. Add the `FIREBASE_SERVICE_ACCOUNT_EXCLUSIVE_ADVENTURES` secret with the JSON key for a Firebase service account.
- Add any API keys (Mailchimp, GA, Coinbase) to GitHub Secrets and reference them in your app via environment variables or a server.

## Replacements & Secrets
- Replace GA4 ID in `index.html` (G-XXXXXXXXXX)
- Replace Mailchimp endpoint and list ID in `src/App.jsx`
- Replace Google Sheets webhook URL
- Add Stripe/coinbase keys to server-side endpoints (never commit them to the repo)

## Crypto Demo Notes
- `src/payments/crypto.js` contains a simple MetaMask connect and send function for testnet demonstration only.
- Use testnet networks and test addresses — do NOT use mainnet private keys in the client.
